;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bubbleberry-theme" "20141017.944"
  "A theme based on LightTable for Emacs24."
  '((emacs "24.1"))
  :url "https://github.com/jasonm23/emacs-bubbleberry-theme"
  :commit "22e9adf4586414024e4592972022ec297321b320"
  :revdesc "22e9adf45864"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
