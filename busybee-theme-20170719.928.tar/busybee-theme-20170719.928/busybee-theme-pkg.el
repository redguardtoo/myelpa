;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "busybee-theme" "20170719.928"
  "Port of vim's mustang theme."
  ()
  :url "http://github.com/mswift42/busybee-theme"
  :commit "66b2315b030582d0ebee605cf455d386d8c30fcd"
  :revdesc "66b2315b0305")
