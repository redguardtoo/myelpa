;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "22"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://www.gnu.org/software/emms/"
  :commit "338462506d7de508f7f74a01d15753f9113cd3cb"
  :revdesc "22-0-g338462506d7d"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
