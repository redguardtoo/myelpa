;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shrink-path" "0.3.1"
  "Fish-style path."
  '((s    "1.6.1")
    (dash "1.8.0")
    (f    "0.10.0"))
  :url "https://gitlab.com/bennya/shrink-path.el"
  :commit "9b8cfb59a2dcee8b39b680ab9adad5ecb1f53c0b"
  :revdesc "9b8cfb59a2dc"
  :keywords '("path"))
