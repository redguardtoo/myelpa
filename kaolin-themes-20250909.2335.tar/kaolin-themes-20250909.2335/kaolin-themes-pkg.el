;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "20250909.2335"
  "A set of eye pleasing themes."
  '((emacs      "25.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "e0db9f421670ee26e1442b89062669e44fcf9454"
  :revdesc "e0db9f421670"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
