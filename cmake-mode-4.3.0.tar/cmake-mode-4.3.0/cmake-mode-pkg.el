;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "4.3.0"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "84aeddb4ea8211e0e9321789a7c8a75ee236f7b9"
  :revdesc "v4.3.0-0-g84aeddb4ea82")
