;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omtose-phellack-themes" "20240928.1241"
  "Two dark themes, with cold blusish touch."
  '((emacs "24"))
  :url "https://github.com/emacsorphanage/omtose-phellack-themes"
  :commit "b96905deb9b2bef097e0c573100874812c1e9aa8"
  :revdesc "b96905deb9b2")
