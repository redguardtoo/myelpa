from anaconda_mode import main
main()
