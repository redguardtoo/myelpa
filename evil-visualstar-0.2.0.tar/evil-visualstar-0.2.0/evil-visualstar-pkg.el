;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-visualstar" "0.2.0"
  "Starts a * or # search from the visual selection."
  '((evil "0"))
  :url "https://github.com/bling/evil-visualstar"
  :commit "eb996eca0081b6e8bab70b2c0a86ef1c71087bf6"
  :revdesc "eb996eca0081"
  :keywords '("evil" "vim" "visualstar"))
