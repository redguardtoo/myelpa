;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20250810.148"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "196f6b9f7c58cb439ed7b0d59c76b1ad737569e0"
  :revdesc "196f6b9f7c58"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
