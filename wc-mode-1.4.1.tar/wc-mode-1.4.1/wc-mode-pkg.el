;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wc-mode" "1.4.1"
  "Running word count with goals (minor mode)."
  '((emacs "24.1"))
  :url "https://github.com/bnbeckwith/wc-mode"
  :commit "63be1433b8a63cdc3239cc751e36360429c42b51"
  :revdesc "63be1433b8a6")
