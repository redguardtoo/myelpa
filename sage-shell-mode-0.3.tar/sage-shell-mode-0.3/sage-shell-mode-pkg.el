;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sage-shell-mode" "0.3"
  "A front-end for Sage Math."
  '((cl-lib    "0.5")
    (emacs     "24.1")
    (let-alist "1.0.4")
    (deferred  "0.4.0"))
  :url "https://github.com/sagemath/sage-shell-mode"
  :commit "e8bc089e8dfd76f688160e2ac77aee985afeade7"
  :revdesc "e8bc089e8dfd"
  :keywords '("sage" "math")
  :authors '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers '(("Sho Takemori" . "stakemorii@gmail.com")))
