;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apropospriate-theme" "20250724.1422"
  "A colorful, low-contrast, light & dark theme set for Emacs with a fun name."
  ()
  :url "http://github.com/waymondo/apropospriate-theme"
  :commit "4457fb40db9893fe92f4afcd9420c37c503701f0"
  :revdesc "4457fb40db98"
  :authors '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainers '(("Justin Talbott" . "justin@waymondo.com")))
