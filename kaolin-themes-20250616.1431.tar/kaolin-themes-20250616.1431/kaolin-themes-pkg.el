;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "20250616.1431"
  "A set of eye pleasing themes."
  '((emacs      "25.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "4b64a70625c1640d369392e9a79cdfd534b8e4be"
  :revdesc "4b64a70625c1"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
