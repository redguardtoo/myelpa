;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abyss-theme" "20260125.1959"
  "A dark theme with contrasting colours."
  '((emacs "24"))
  :url "https://github.com/mgrbyte/emacs-abyss-theme"
  :commit "6eb2b5735808ea96a36fc7abf741fc3bbf1b6ee4"
  :revdesc "6eb2b5735808"
  :keywords '("theme" "dark" "contrasting colours")
  :authors '(("Matt Russell" . "mgrbyte@member.fsf.org"))
  :maintainers '(("Matt Russell" . "mgrbyte@member.fsf.org")))
