;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "1.2"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "d7896e9594d45d7b2622d4617ff9cb7037378167"
  :revdesc "v1.2-0-gd7896e9594d4"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
