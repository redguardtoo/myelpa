;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srcery-theme" "20250523.1304"
  "Dark color theme."
  '((emacs "24"))
  :url "https://github.com/srcery-colors/srcery-emacs"
  :commit "55771c3190f2ed2fdcde3d6e6e94d4366830657c"
  :revdesc "55771c3190f2"
  :keywords '("faces"))
