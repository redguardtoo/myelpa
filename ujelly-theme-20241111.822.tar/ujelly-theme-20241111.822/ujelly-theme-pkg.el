;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ujelly-theme" "20241111.822"
  "Ujelly theme for GNU Emacs 24 (deftheme)."
  ()
  :url "http://github.com/marktran/color-theme-ujelly"
  :commit "7345ab821739aafa2ec079a71fa7de350a869f0e"
  :revdesc "7345ab821739"
  :authors '(("Mark Tran" . "mark.tran@gmail.com"))
  :maintainers '(("Mark Tran" . "mark.tran@gmail.com")))
