(define-package "zen-and-art-theme" "20120622.1437" "zen and art color theme for GNU Emacs 24" 'nil :commit "a7226cbce0bca2501d69a620cb2aeabfc396c232" :authors
  '(("Nick Parker"))
  :maintainers
  '(("Nick Parker"))
  :maintainer
  '("Nick Parker"))
;; Local Variables:
;; no-byte-compile: t
;; End:
