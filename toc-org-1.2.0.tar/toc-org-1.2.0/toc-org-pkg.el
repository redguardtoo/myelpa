;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toc-org" "1.2.0"
  "Add table of contents to org-mode files (formerly, org-toc)."
  ()
  :url "https://github.com/snosov1/toc-org"
  :commit "df4ad6ff15e3b02f6322305638a441a636b9b37e"
  :revdesc "df4ad6ff15e3"
  :keywords '("org-mode" "org-toc" "toc-org" "org" "toc" "table" "of" "contents")
  :authors '(("Sergei Nosov" . "sergei.nosov[at]gmail.com"))
  :maintainers '(("Sergei Nosov" . "sergei.nosov[at]gmail.com")))
