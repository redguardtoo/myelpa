;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dictionary" "1.11"
  "Client for rfc2229 dictionary servers."
  '((connection "1.11")
    (link       "1.11"))
  :url "https://github.com/myrkr/dictionary-el"
  :commit "c9cad101100975e88873636bfd426b7a19304ebd"
  :revdesc "c9cad1011009"
  :keywords '("interface" "dictionary")
  :authors '(("Torsten Hilbrich" . "torsten.hilbrich@gmx.net"))
  :maintainers '(("Torsten Hilbrich" . "torsten.hilbrich@gmx.net")))
