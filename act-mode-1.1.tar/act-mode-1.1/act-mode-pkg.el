;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "act-mode" "1.1"
  "Major mode for the ACT programming language."
  '((emacs "26.1"))
  :url "https://github.com/rafaelcn/act"
  :commit "90d7d626691591b24d83596149bc89fd51ba39b4"
  :revdesc "1.1-0-g90d7d6266915")
