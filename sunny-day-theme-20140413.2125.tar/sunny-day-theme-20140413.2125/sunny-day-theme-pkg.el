(define-package "sunny-day-theme" "20140413.2125" "Emacs24 theme with a light background." 'nil :commit "420e0a6eb33fcc9b75c2c9e88ab60a975d782a00" :authors
  '(("Martin Haesler"))
  :maintainers
  '(("Martin Haesler"))
  :maintainer
  '("Martin Haesler")
  :url "http://github.com/mswift42/sunny-day-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
