;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-regexp" "1.1.2"
  "A regexp/replace command for Emacs with interactive visual feedback."
  '((cl-lib "0.2"))
  :url "https://github.com/benma/visual-regexp.el/"
  :commit "3e3ed81a3cbadef1f1f4cb16f9112a58641d70ca"
  :revdesc "v1.1.2-0-g3e3ed81a3cba"
  :keywords '("regexp" "replace" "visual" "feedback")
  :authors '(("Marko Bencun" . "mbencun@gmail.com"))
  :maintainers '(("Marko Bencun" . "mbencun@gmail.com")))
